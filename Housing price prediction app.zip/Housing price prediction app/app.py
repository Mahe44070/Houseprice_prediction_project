from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)
model = pickle.load(open('static/model.pkl', 'rb'))

@app.route('/', methods=['GET', 'POST'])
def predict():
    predicted_price = None

    if request.method == 'POST':
        feature1 = float(request.form.get('feature1', 0)) 
        feature2 = float(request.form.get('feature2', 0))
        feature3 = float(request.form.get('feature3', 0))
        feature4 = float(request.form.get('feature4', 0))
        feature5 = request.form.get('feature5', 'no')  
        feature6 = request.form.get('feature6', 'no')  
        feature7 = request.form.get('feature7', 'no')  
        feature8 = request.form.get('feature8', 'no')  
        feature9 = request.form.get('feature9', 'no')  
        feature10 = float(request.form.get('feature10', 0))
        feature11 = request.form.get('feature11', 'no') 
        feature12 = float(request.form.get('feature12', 0))  

        mainroad_mapping = {'yes': 1, 'no': 2}
        feature5 = mainroad_mapping.get(feature5.lower(), 2)  

        guestroom_mapping = {'yes': 1, 'no': 2}
        feature6 = guestroom_mapping.get(feature6.lower(), 2)  

        basement_mapping = {'yes': 1, 'no': 2}
        feature7 = basement_mapping.get(feature7.lower(), 2)    

        hotwaterheating_mapping = {'yes': 1, 'no': 2}
        feature8 = hotwaterheating_mapping.get(feature8.lower(), 2)         

        airconditioning_mapping = {'yes': 1, 'no': 2}
        feature9 = airconditioning_mapping.get(feature9.lower(), 2)  

        prefarea_mapping = {'yes': 1, 'no': 2}
        feature11 = prefarea_mapping.get(feature11.lower(), 2)  

        features = np.array([feature1, feature2, feature3, feature4, feature5, feature6, feature7, feature8, feature9, feature10, feature11, feature12])
        features = features.astype(np.float64)
        pred = model.predict([features])[0]

        predicted_price = round(pred, 2) 

    return render_template('index.html', data=predicted_price)

if __name__ == '__main__':
    model = pickle.load(open('static\model.pkl','rb'))

    app.run(debug=True, port=4000)
